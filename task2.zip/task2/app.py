from flask import Flask, request, jsonify, redirect, url_for, render_template
from flask_pymongo import PyMongo
from bson import ObjectId

# Initialize Flask and MongoDB
app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/employee_db'  # MongoDB URI
mongo = PyMongo(app)

# Route to serve admin.html on server start
@app.route('/')
def index():
    return redirect(url_for('admin_page'))

# Serve admin page
@app.route('/admin')
def admin_page():
    return render_template('admin.html')  # Render admin.html page

# Route to add a new employee
@app.route('/api/employees', methods=['POST'])
def add_employee():
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    department = data.get('department')

    if not name or not email or not department:
        return jsonify({'message': 'Missing required fields'}), 400

    employee = {
        'name': name,
        'email': email,
        'department': department
    }

    employee_id = mongo.db.employees.insert_one(employee).inserted_id
    employee['_id'] = str(employee_id)

    return jsonify(employee), 201

# Route to get all employees
@app.route('/api/employees', methods=['GET'])
def get_employees():
    employees = mongo.db.employees.find()
    employee_list = []
    for employee in employees:
        employee['_id'] = str(employee['_id'])
        employee_list.append(employee)
    
    return jsonify(employee_list), 200

# Route to get a single employee by ID for updating
@app.route('/api/employees/<id>', methods=['GET'])
def get_employee(id):
    employee = mongo.db.employees.find_one({'_id': ObjectId(id)})
    if not employee:
        return jsonify({'message': 'Employee not found'}), 404

    employee['_id'] = str(employee['_id'])  # Convert ObjectId to string for JSON response
    return jsonify(employee), 200

# Route to update an employee by ID
@app.route('/api/employees/<id>', methods=['PUT'])
def update_employee(id):
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    department = data.get('department')

    employee = mongo.db.employees.find_one({'_id': ObjectId(id)})
    if not employee:
        return jsonify({'message': 'Employee not found'}), 404

    # Update employee details
    updated_employee = {}
    if name:
        updated_employee['name'] = name
    if email:
        updated_employee['email'] = email
    if department:
        updated_employee['department'] = department

    mongo.db.employees.update_one({'_id': ObjectId(id)}, {'$set': updated_employee})

    updated_employee['_id'] = id
    return jsonify(updated_employee), 200

# Route to delete an employee by ID
@app.route('/api/employees/<id>', methods=['DELETE'])
def delete_employee(id):
    employee = mongo.db.employees.find_one({'_id': ObjectId(id)})
    if not employee:
        return jsonify({'message': 'Employee not found'}), 404

    mongo.db.employees.delete_one({'_id': ObjectId(id)})
    return jsonify({'message': 'Employee deleted successfully'}), 200

if __name__ == '__main__':
    app.run(debug=True, port=3000)
